QUERTAXI - Estrutura do Projeto
